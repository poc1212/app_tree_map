// executa function ao carregar pagina
window.onload = function(){

    let radios1 = document.querySelectorAll(".radio1");

    if(radios1){

        for(let radio of radios1){

            radio.addEventListener("click", () => {

                let ativo1 = document.getElementById("ativo1");
                let ativo2 = document.getElementById("ativo2");
                              
                // inicio logica
                if(ativo1){

                    let volume1 = document.getElementById("volume1");
                    let volume2 = document.getElementById("volume2");
                    
                    if(radio.value === "-30"){

                        ativo1.style.width = "171px";
                        ativo1.style.background = "#C3002C";
                        volume1.innerHTML = "Volume: -30%";

                        ativo2.style.width = "317px";
                        ativo2.style.background = "#02911F";
                        volume2.innerHTML = "Volume: 30%";

                        let ativo11 = document.getElementById("14");
                        ativo11.checked = true;

                    }else if(radio.value === "-20"){

                        ativo1.style.width = "196px";
                        ativo1.style.background = "#FF2655";
                        volume1.innerHTML = "Volume: -20%";

                        ativo2.style.width = "292px";
                        ativo2.style.background = "#02B126";
                        volume2.innerHTML = "Volume: 20%";

                        let ativo11 = document.getElementById("13");
                        ativo11.checked = true;
                        
                    }else if(radio.value === "-10"){

                        ativo1.style.width = "219px";
                        ativo1.style.background = "#FF89A2";
                        volume1.innerHTML = "Volume: -10%";

                        ativo2.style.width = "268px";
                        ativo2.style.background = "#1AFB47";
                        volume2.innerHTML = "Volume: 10%";

                        let ativo11 = document.getElementById("12");
                        ativo11.checked = true;

                    }else if(radio.value === "0"){

                        ativo1.style.width = "244px";
                        ativo1.style.background = "#00A8FF";
                        volume1.innerHTML = "Volume: 0%";

                        ativo2.style.width = "244px";
                        ativo2.style.background = "#00A8FF";
                        volume2.innerHTML = "Volume: 0%";

                        let ativo11 = document.getElementById("11");
                        ativo11.checked = true;
                        
                    }else if(radio.value === "10"){

                        ativo1.style.width = "268px";
                        ativo1.style.background = "#1AFB47";
                        volume1.innerHTML = "Volume: 10%";

                        ativo2.style.width = "219px";
                        ativo2.style.background = "#FF89A2";
                        volume2.innerHTML = "Volume: -10%";

                        let ativo11 = document.getElementById("10");
                        ativo11.checked = true;

                    }else if(radio.value === "20"){

                        ativo1.style.width = "292px";
                        ativo1.style.background = "#02B126";
                        volume1.innerHTML = "Volume: 20%";

                        ativo2.style.width = "196px";
                        ativo2.style.background = "#FF2655";
                        volume2.innerHTML = "Volume: -20%";

                        let ativo11 = document.getElementById("9");
                        ativo11.checked = true;

                    }else if(radio.value === "30"){

                        ativo1.style.width = "317px";
                        ativo1.style.background = "#02911F";
                        volume1.innerHTML = "Volume: 30%";

                        ativo2.style.width = "171px";
                        ativo2.style.background = "#C3002C";
                        volume2.innerHTML = "Volume: -30%";

                        let ativo11 = document.getElementById("8");
                        ativo11.checked = true;
                    }
                }
            });
        }
    }

    let radios2 = document.querySelectorAll(".radio2");


    if(radios2){

        for(let radio of radios2){

            radio.addEventListener("click", () => {

                let ativo2 = document.getElementById("ativo2");
                let ativo1 = document.getElementById("ativo1");

                if(ativo2){

                    let volume2 = document.getElementById("volume2");
                    let volume1 = document.getElementById("volume1");

                    if(radio.value === "-30"){

                        ativo2.style.width = "171px";
                        ativo2.style.background = "#C3002C";
                        volume2.innerHTML = "Volume: -30%";

                        ativo1.style.width = "317px";
                        ativo1.style.background = "#02911F";
                        volume1.innerHTML = "Volume: 30%";

                        let ativo12 = document.getElementById("7");
                        ativo12.checked = true;                        

                    }else if(radio.value === "-20"){

                        ativo2.style.width = "196px";
                        ativo2.style.background = "#FF2655";
                        volume2.innerHTML = "Volume: -20%";

                        ativo1.style.width = "292px";
                        ativo1.style.background = "#02B126";
                        volume1.innerHTML = "Volume: 20%";

                        let ativo12 = document.getElementById("6");
                        ativo12.checked = true;

                    }else if(radio.value === "-10"){

                        ativo2.style.width = "219px";
                        ativo2.style.background = "#FF89A2";
                        volume2.innerHTML = "Volume: -10%";

                        ativo1.style.width = "268px";
                        ativo1.style.background = "#1AFB47";
                        volume1.innerHTML = "Volume: 10%";

                        let ativo12 = document.getElementById("5");
                        ativo12.checked = true;

                    }else if(radio.value === "0"){

                        ativo2.style.width = "244px";
                        ativo2.style.background = "#00A8FF";
                        volume2.innerHTML = "Volume: 0%";

                        ativo1.style.width = "244px";
                        ativo1.style.background = "#00A8FF";
                        volume1.innerHTML = "Volume: 0%";

                        let ativo12 = document.getElementById("4");
                        ativo12.checked = true;
                        
                    }else if(radio.value === "10"){

                        ativo2.style.width = "268px";
                        ativo2.style.background = "#1AFB47";
                        volume2.innerHTML = "Volume: 10%";

                        ativo1.style.width = "219px";
                        ativo1.style.background = "#FF89A2";
                        volume1.innerHTML = "Volume: -10%";

                        let ativo12 = document.getElementById("3");
                        ativo12.checked = true;

                    }else if(radio.value === "20"){

                        ativo2.style.width = "292px";
                        ativo2.style.background = "#02B126";
                        volume2.innerHTML = "Volume: 20%";

                        ativo1.style.width = "196px";
                        ativo1.style.background = "#FF2655";
                        volume1.innerHTML = "Volume: -20%";

                        let ativo12 = document.getElementById("2");
                        ativo12.checked = true;
                            
                    }else if(radio.value === "30"){

                        ativo2.style.width = "317px";
                        ativo2.style.background = "#02911F";
                        volume2.innerHTML = "Volume: 30%";

                        ativo1.style.width = "171px";
                        ativo1.style.background = "#C3002C";
                        volume1.innerHTML = "Volume: -30%";

                        let ativo12 = document.getElementById("1");
                        ativo12.checked = true;
                    }
                }
            });
        }
    }

    let radios3 = document.querySelectorAll(".radio3");

    if(radios3){

        for(let radio of radios3){

            radio.addEventListener("click", () => {

                let ativo3 = document.getElementById("ativo3");
                let ativo4 = document.getElementById("ativo4");

                if(ativo3){

                    let volume3 = document.getElementById("volume3");
                    let volume4 = document.getElementById("volume4");

                    if(radio.value === "-30"){

                        ativo3.style.width = "171px";
                        ativo3.style.background = "#C3002C";
                        volume3.innerHTML = "Volume: -30%";

                        ativo4.style.width = "317px";
                        ativo4.style.background = "#02911F";
                        volume4.innerHTML = "Volume: 30%";

                        let ativo13 = document.getElementById("28");
                        ativo13.checked = true;

                    }else if(radio.value === "-20"){

                        ativo3.style.width = "196px";
                        ativo3.style.background = "#FF2655";
                        volume3.innerHTML = "Volume: -20%";

                        ativo4.style.width = "292px";
                        ativo4.style.background = "#02B126";
                        volume4.innerHTML = "Volume: 20%";

                        let ativo13 = document.getElementById("27");
                        ativo13.checked = true

                    }else if(radio.value === "-10"){

                        ativo3.style.width = "219px";
                        ativo3.style.background = "#FF89A2";
                        volume3.innerHTML = "Volume: -10%";

                        ativo4.style.width = "268px";
                        ativo4.style.background = "#1AFB47";
                        volume4.innerHTML = "Volume: 10%";

                        let ativo13 = document.getElementById("26");
                        ativo13.checked = true;

                    }else if(radio.value === "0"){

                        ativo3.style.width = "244px";
                        ativo3.style.background = "#00A8FF";
                        volume3.innerHTML = "Volume: 0%";

                        ativo4.style.width = "244px";
                        ativo4.style.background = "#00A8FF";
                        volume4.innerHTML = "Volume: 0%";

                        let ativo13 = document.getElementById("25");
                        ativo13.checked = true;
                        
                    }else if(radio.value === "10"){

                        ativo3.style.width = "268px";
                        ativo3.style.background = "#1AFB47";
                        volume3.innerHTML = "Volume: 10%";

                        ativo4.style.width = "219px";
                        ativo4.style.background = "#FF89A2";
                        volume4.innerHTML = "Volume: -10%";

                        let ativo13 = document.getElementById("24");
                        ativo13.checked = true;

                    }else if(radio.value === "20"){

                        ativo3.style.width = "292px";
                        ativo3.style.background = "#02B126";
                        volume3.innerHTML = "Volume: 20%";

                        ativo4.style.width = "196px";
                        ativo4.style.background = "#FF2655";
                        volume4.innerHTML = "Volume: -20%";

                        let ativo13 = document.getElementById("23");
                        ativo13.checked = true;
                            
                    }else if(radio.value === "30"){

                        ativo3.style.width = "317px";
                        ativo3.style.background = "#02911F";
                        volume3.innerHTML = "Volume: 30%";

                        ativo4.style.width = "171px";
                        ativo4.style.background = "#C3002C";
                        volume4.innerHTML = "Volume: -30%";

                        let ativo13 = document.getElementById("22");
                        ativo13.checked = true;
                    }
                }
            });
        }
    }

    let radios4 = document.querySelectorAll(".radio4");

    if(radios4){

        for(let radio of radios4){

            radio.addEventListener("click", () => {

                let ativo4 = document.getElementById("ativo4");
                let ativo3 = document.getElementById("ativo3");

                if(ativo4){

                    let volume4 = document.getElementById("volume4");
                    let volume3 = document.getElementById("volume3");

                    if(radio.value === "-30"){

                        ativo4.style.width = "171px";
                        ativo4.style.background = "#C3002C";
                        volume4.innerHTML = "Volume: -30%";

                        ativo3.style.width = "317px";
                        ativo3.style.background = "#02911F";
                        volume3.innerHTML = "Volume: 30%";

                        let ativo14 = document.getElementById("21");
                        ativo14.checked = true;

                    }else if(radio.value === "-20"){

                        ativo4.style.width = "196px";
                        ativo4.style.background = "#FF2655";
                        volume4.innerHTML = "Volume: -20%";

                        ativo3.style.width = "292px";
                        ativo3.style.background = "#02B126";
                        volume3.innerHTML = "Volume: 20%";

                        let ativo14 = document.getElementById("20");
                        ativo14.checked = true

                    }else if(radio.value === "-10"){

                        ativo4.style.width = "219px";
                        ativo4.style.background = "#FF89A2";
                        volume4.innerHTML = "Volume: -10%";

                        ativo3.style.width = "268px";
                        ativo3.style.background = "#1AFB47";
                        volume3.innerHTML = "Volume: 10%";

                        let ativo14 = document.getElementById("19");
                        ativo14.checked = true;

                    }else if(radio.value === "0"){

                        ativo4.style.width = "244px";
                        ativo4.style.background = "#00A8FF";
                        volume4.innerHTML = "Volume: 0%";

                        ativo3.style.width = "244px";
                        ativo3.style.background = "#00A8FF";
                        volume3.innerHTML = "Volume: 0%";

                        let ativo14 = document.getElementById("18");
                        ativo14.checked = true;
                        
                    }else if(radio.value === "10"){

                        ativo4.style.width = "268px";
                        ativo4.style.background = "#1AFB47";
                        volume4.innerHTML = "Volume: 10%";

                        ativo3.style.width = "219px";
                        ativo3.style.background = "#FF89A2";
                        volume3.innerHTML = "Volume: -10%";

                        let ativo14 = document.getElementById("17");
                        ativo14.checked = true;

                    }else if(radio.value === "20"){

                        ativo4.style.width = "292px";
                        ativo4.style.background = "#02B126";
                        volume4.innerHTML = "Volume: 20%";

                        ativo3.style.width = "196px";
                        ativo3.style.background = "#FF2655";
                        volume3.innerHTML = "Volume: -20%";

                        let ativo14 = document.getElementById("16");
                        ativo14.checked = true;
                            
                    }else if(radio.value === "30"){

                        ativo4.style.width = "317px";
                        ativo4.style.background = "#02911F";
                        volume4.innerHTML = "Volume: 30%";

                        ativo3.style.width = "171px";
                        ativo3.style.background = "#C3002C";
                        volume3.innerHTML = "Volume: -30%";

                        let ativo14 = document.getElementById("15");
                        ativo14.checked = true;
                    }
                }
            });
        }
    }


    let radios5 = document.querySelectorAll(".radio5");

    if(radios5){

        for(let radio of radios5){

            radio.addEventListener("click", () => {

                let ativo5 = document.getElementById("ativo5");
                let ativo6 = document.getElementById("ativo6");

                if(ativo5){

                    let volume5 = document.getElementById("volume5");
                    let volume6 = document.getElementById("volume6");

                    if(radio.value === "-30"){

                        ativo5.style.width = "171px";
                        ativo5.style.background = "#C3002C";
                        volume5.innerHTML = "Volume: -30%";

                        ativo6.style.width = "317px";
                        ativo6.style.background = "#02911F";
                        volume6.innerHTML = "Volume: 30%";

                        let ativo15 = document.getElementById("42");
                        ativo15.checked = true;

                    }else if(radio.value === "-20"){

                        ativo5.style.width = "196px";
                        ativo5.style.background = "#FF2655";
                        volume5.innerHTML = "Volume: -20%";

                        ativo6.style.width = "292px";
                        ativo6.style.background = "#02B126";
                        volume6.innerHTML = "Volume: 20%";

                        let ativo15 = document.getElementById("41");
                        ativo15.checked = true

                    }else if(radio.value === "-10"){

                        ativo5.style.width = "219px";
                        ativo5.style.background = "#FF89A2";
                        volume5.innerHTML = "Volume: -10%";

                        ativo6.style.width = "268px";
                        ativo6.style.background = "#1AFB47";
                        volume6.innerHTML = "Volume: 10%";

                        let ativo15 = document.getElementById("40");
                        ativo15.checked = true;

                    }else if(radio.value === "0"){

                        ativo5.style.width = "244px";
                        ativo5.style.background = "#00A8FF";
                        volume5.innerHTML = "Volume: 0%";

                        ativo6.style.width = "244px";
                        ativo6.style.background = "#00A8FF";
                        volume6.innerHTML = "Volume: 0%";

                        let ativo15 = document.getElementById("39");
                        ativo15.checked = true;
                        
                    }else if(radio.value === "10"){

                        ativo5.style.width = "268px";
                        ativo5.style.background = "#1AFB47";
                        volume5.innerHTML = "Volume: 10%";

                        ativo6.style.width = "219px";
                        ativo6.style.background = "#FF89A2";
                        volume6.innerHTML = "Volume: -10%";

                        let ativo15 = document.getElementById("38");
                        ativo15.checked = true;

                    }else if(radio.value === "20"){

                        ativo5.style.width = "292px";
                        ativo5.style.background = "#02B126";
                        volume5.innerHTML = "Volume: 20%";

                        ativo6.style.width = "196px";
                        ativo6.style.background = "#FF2655";
                        volume6.innerHTML = "Volume: -20%";

                        let ativo15 = document.getElementById("37");
                        ativo15.checked = true;
                            
                    }else if(radio.value === "30"){

                        ativo5.style.width = "317px";
                        ativo5.style.background = "#02911F";
                        volume5.innerHTML = "Volume: 30%";

                        ativo6.style.width = "171px";
                        ativo6.style.background = "#C3002C";
                        volume6.innerHTML = "Volume: -30%";

                        let ativo15 = document.getElementById("36");
                        ativo15.checked = true;
                    }
                }
            });
        }
    }

    let radios6 = document.querySelectorAll(".radio6");

    if(radios6){

        for(let radio of radios6){

            radio.addEventListener("click", () => {

                let ativo6 = document.getElementById("ativo6");
                let ativo5 = document.getElementById("ativo5");

                if(ativo6){

                    let volume6 = document.getElementById("volume6");
                    let volume5 = document.getElementById("volume5");

                    if(radio.value === "-30"){

                        ativo6.style.width = "171px";
                        ativo6.style.background = "#C3002C";
                        volume6.innerHTML = "Volume: -30%";

                        ativo5.style.width = "317px";
                        ativo5.style.background = "#02911F";
                        volume5.innerHTML = "Volume: 30%";

                        let ativo16 = document.getElementById("35");
                        ativo16.checked = true;

                    }else if(radio.value === "-20"){

                        ativo6.style.width = "196px";
                        ativo6.style.background = "#FF2655";
                        volume6.innerHTML = "Volume: -20%";

                        ativo5.style.width = "292px";
                        ativo5.style.background = "#02B126";
                        volume5.innerHTML = "Volume: 20%";

                        let ativo16 = document.getElementById("34");
                        ativo16.checked = true

                    }else if(radio.value === "-10"){

                        ativo6.style.width = "219px";
                        ativo6.style.background = "#FF89A2";
                        volume6.innerHTML = "Volume: -10%";

                        ativo5.style.width = "268px";
                        ativo5.style.background = "#1AFB47";
                        volume5.innerHTML = "Volume: 10%";

                        let ativo16 = document.getElementById("33");
                        ativo16.checked = true;

                    }else if(radio.value === "0"){

                        ativo6.style.width = "244px";
                        ativo6.style.background = "#00A8FF";
                        volume6.innerHTML = "Volume: 0%";

                        ativo5.style.width = "244px";
                        ativo5.style.background = "#00A8FF";
                        volume5.innerHTML = "Volume: 0%";

                        let ativo16 = document.getElementById("32");
                        ativo16.checked = true;
                        
                    }else if(radio.value === "10"){

                        ativo6.style.width = "268px";
                        ativo6.style.background = "#1AFB47";
                        volume6.innerHTML = "Volume: 10%";

                        ativo5.style.width = "219px";
                        ativo5.style.background = "#FF89A2";
                        volume5.innerHTML = "Volume: -10%";

                        let ativo16 = document.getElementById("31");
                        ativo16.checked = true;

                    }else if(radio.value === "20"){

                        ativo6.style.width = "292px";
                        ativo6.style.background = "#02B126";
                        volume6.innerHTML = "Volume: 20%";

                        ativo5.style.width = "196px";
                        ativo5.style.background = "#FF2655";
                        volume5.innerHTML = "Volume: -20%";

                        let ativo16 = document.getElementById("30");
                        ativo16.checked = true;
                            
                    }else if(radio.value === "30"){

                        ativo6.style.width = "317px";
                        ativo6.style.background = "#02911F";
                        volume6.innerHTML = "Volume: 30%";

                        ativo5.style.width = "171px";
                        ativo5.style.background = "#C3002C";
                        volume5.innerHTML = "Volume: -30%";

                        let ativo16 = document.getElementById("29");
                        ativo16.checked = true;
                    }
                }
            });
        }
    }
}